title: idea发布jar包的三种方式
date: '2019-12-11 18:28:55'
updated: '2019-12-12 09:19:22'
tags: [idea]
permalink: /articles/2019/12/11/1576060135279.html
---
记录idea发布jar的三种方式，方便查询，转自：https://blog.csdn.net/gslsxqrj/article/details/82624157
三种方式中，视情况而定，依赖和代码可以分开发布的情况推荐第三种，因为依赖不经常更换，而且依赖的jar包一般都比较大
### 1、所有依赖都放入一个jar包
（1）从File进入Project Structure,选中Artifacts
![1](https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/idea%E6%89%93%E5%8C%85jar/%E7%AC%AC%E4%B8%80%E7%A7%8D%E6%96%B9%E5%BC%8F/1-min.jpg)
（2）点击From module with dependencies...
![2](https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/idea%E6%89%93%E5%8C%85jar/%E7%AC%AC%E4%B8%80%E7%A7%8D%E6%96%B9%E5%BC%8F/2-min.jpg)
(3)选择MainClass和MANIFEST.INF输出目录,其中MANIFEST.INF可以随便固定保存在一个地方,因为Idea要保存此配置下次打开会用到配置文件MANIFEST.INF,点击OK
![3](https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/idea%E6%89%93%E5%8C%85jar/%E7%AC%AC%E4%B8%80%E7%A7%8D%E6%96%B9%E5%BC%8F/3-min.jpg)
(4) 弹出如下界面,点击ok即可
![4](https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/idea%E6%89%93%E5%8C%85jar/%E7%AC%AC%E4%B8%80%E7%A7%8D%E6%96%B9%E5%BC%8F/4-min.jpg)
(5)开始生成jar包,选择Builder->Build Artifacts...
![5.1](https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/idea%E6%89%93%E5%8C%85jar/%E7%AC%AC%E4%B8%80%E7%A7%8D%E6%96%B9%E5%BC%8F/5-min.jpg)
![5.2](https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/idea%E6%89%93%E5%8C%85jar/%E7%AC%AC%E4%B8%80%E7%A7%8D%E6%96%B9%E5%BC%8F/6-min.jpg)
(6)刚才生成的jar包如下,所有依赖jar都浓缩在一个jar包下
![6]( https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/idea%E6%89%93%E5%8C%85jar/%E7%AC%AC%E4%B8%80%E7%A7%8D%E6%96%B9%E5%BC%8F/7-min.jpg)
### 2、A.jar所依赖的jar包在同一级目录下

![1]( https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/idea%E6%89%93%E5%8C%85jar/%E7%AC%AC%E4%BA%8C%E7%A7%8D%E6%96%B9%E5%BC%8F/1-min.jpg)

![2]( https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/idea%E6%89%93%E5%8C%85jar/%E7%AC%AC%E4%BA%8C%E7%A7%8D%E6%96%B9%E5%BC%8F/2-min.jpg)

![3]( https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/idea%E6%89%93%E5%8C%85jar/%E7%AC%AC%E4%BA%8C%E7%A7%8D%E6%96%B9%E5%BC%8F/3-min.jpg)
### 3、A.jar和lib文件夹同一级目录,lib包含所依赖的jar包
![1](https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/idea%E6%89%93%E5%8C%85jar/%E7%AC%AC%E4%B8%89%E7%A7%8D%E6%96%B9%E5%BC%8F/1-min.jpg)

![2](https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/idea%E6%89%93%E5%8C%85jar/%E7%AC%AC%E4%B8%89%E7%A7%8D%E6%96%B9%E5%BC%8F/2-min.jpg)


![3](https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/idea%E6%89%93%E5%8C%85jar/%E7%AC%AC%E4%B8%89%E7%A7%8D%E6%96%B9%E5%BC%8F/3-min.jpg)

![4](https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/idea%E6%89%93%E5%8C%85jar/%E7%AC%AC%E4%B8%89%E7%A7%8D%E6%96%B9%E5%BC%8F/4-min.jpg)

![5](https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/idea%E6%89%93%E5%8C%85jar/%E7%AC%AC%E4%B8%89%E7%A7%8D%E6%96%B9%E5%BC%8F/5-min.jpg)

![6](https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/idea%E6%89%93%E5%8C%85jar/%E7%AC%AC%E4%B8%89%E7%A7%8D%E6%96%B9%E5%BC%8F/6-min.jpg)

![7](https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/idea%E6%89%93%E5%8C%85jar/%E7%AC%AC%E4%B8%89%E7%A7%8D%E6%96%B9%E5%BC%8F/7-min.jpg)

![8](https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/idea%E6%89%93%E5%8C%85jar/%E7%AC%AC%E4%B8%89%E7%A7%8D%E6%96%B9%E5%BC%8F/8-min.jpg)
