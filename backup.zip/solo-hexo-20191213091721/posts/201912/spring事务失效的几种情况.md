title: spring事务失效的几种情况
date: '2019-12-12 10:45:55'
updated: '2019-12-12 10:45:55'
tags: [spring]
permalink: /articles/2019/12/12/1576118755620.html
---
spring 事务经常会使用到，对于什么情况下失效，是非常有必要了解的，下面总结一下会失效的几种情况。
### 1、spring事务实现的原理
spring事务的本质是数据库对事务的支持：JDBC的commint()提交事务、rollback()回滚事务；
spring支持编程式事务管理和声明式事务管理两种方式。
（1）编程式事务管理使用TransactionTemplate或者直接使用底层的PlatformTransactionManager。对于编程式事务管理，spring推荐使用TransactionTemplate。
（2）声明式事务管理建立在AOP之上的。其本质是对方法前后进行拦截，然后在目标方法开始之前创建或者加入一个事务，在执行完目标方法之后根据执行情况提交或者回滚事务。声明式事务最大的优点是只需在配置文件中做相关的事务规则声明(或通过基于@Transactional注解的方式)，便可以将事务规则应用到业务逻辑中。

### 2、spring事务失效的几种情况
（1）同一个类中, 一个未标注@Transactional的方法去调用标有@Transactional的方法, 事务会失效

（2）在非public（例如：private、protected、final、static）方法上标注@Transactional, 事务会无效

（3）如果采用spring+spring mvc，则context:component-scan重复扫描问题可能会引起事务失效
　　因为按照spring配置文件的加载顺序来讲，先加载springmvc配置文件，再加载spring配置文件，我们的事物一般都在srping配置文件中进行配置，如果此时在加载srpingMVC配置文件的时候，把servlce也给注册了，但是此时事物还没加载，也就导致后面的事物无法成功注入到service中。所以把对service的扫描放在spring配置文件中或是其他配置文件中。

（4）使用mysql且引擎是MyISAM，则事务会不起作用，原因是MyISAM不支持事务，可以改成InnoDB引擎

（5）@Transactional 注解开启配置，必须放到listener里加载，如果放到DispatcherServlet的配置里，事务也是不起作用的

（6）Spring团队建议在具体的类（或类的方法）上使用 @Transactional 注解，而不要使用在类所要实现的任何接口上。在接口上使用 @Transactional 注解，只能当你设置了基于接口的代理时它才生效。因为注解是不能继承的，这就意味着如果正在使用基于类的代理时，那么事务的设置将不能被基于类的代理所识别，而且对象也将不会被事务代理所包装。

（7）spring事务只在发生未被捕获的RuntimeException和Error异常时才回滚，但是抛出其他Exception，事务不回滚（可以设置：rollback-for="Exception”,所有异常都回滚）
　　换句话说在service的方法中不使用try catch 或者在catch中最后加上throw new RuntimeException（），这样程序异常时才能被aop捕获进而回滚


