title: try caych finally的正确用法
date: '2019-10-17 11:52:50'
updated: '2019-11-14 22:09:24'
tags: [异常处理]
permalink: /articles/2019/10/17/1571284369901.html
---
### 一、首先要理解finally
　　仅仅在下面4中情况下不会执行finally语句：
　　1、如果在try 或catch语句中执行了System.exit(0)；
　　2、在执行finally之前jvm崩溃了；
　　3、try语句中执行死循环；
　　4、电源断电；
　　除了以上的四种情况外，finally语句都会执行，finally语句执行时会有以下原则;
　　1、不管有没有出现异常，finally块中代码都会执行；
　　2、当try和catch中有return时，finally仍然会执行；
　　3、finally是在return后面的表达式运算后执行的（此时并没有返回运算后的值，而是先把要返回的值保存起来，管finally中的代码怎么样，返回的值都不会改变，任然是之前保存的值），所以函数返回值是在finally执行前确定的；
　　4、finally中最好不要包含return，否则程序会提前退出，返回值不是try或catch中保存的返回值;

### 二、具体场景
　　场景1：try{return;}catch{}finally{} return;
　　执行步骤： a) 执行try{}部分（包括return表达式）; b) 执行finally{}部分; c) 返回try{}中return表达式结果.
　　场景2：try{}catch{}finally{} return；try有异常场景;
　　执行顺序： a) 执行try块抛出异常；b)catch拦截了异常并执行处理逻辑； c) 执行try中return 表达式；d)执行finally块; e) 执行return表达式返回值
　　场景3： try{return;} catch{} finally{return;}
　　执行顺序： a) 执行try块，并执行其中return表达式; b) 执行finally块； c) 执行finally中return 表达式；d) 返回finally中return表达式结果（PS：由于finally中有return语句则直接返回退出）
　　场景4：try{return;} catch{return;} finally{return;} try有异常
　　执行顺序： a) 执行try块，并抛出异常； b) catch获取异常，执行其中语句，并执行其中return语句；c) 执行finally块中语句并执行return语句；d)返回finally语句中return结果集（由于finally中有return则直接返回退出）
　　场景5: try{}finally{}中引用类型对象发生修改
　　执行步骤： a) 执行try{}中块并执行return user语句；b)执行finally语句修改了u的属性name；c)返回u。(PS user属性竟然发生改变啦!)
　　场景6: try{}finally{}中引用类型对象返回
　　执行步骤 ： 与场景3同

### 三、异常类型
　　Exception类的异常包括checked exception和unchecked exception（unchecked exception也称运行时异常RuntimeException，当然这里的运行时异常并不是前面我所说的运行期间的异常，只是Java中用运行时异常这个术语来表示，Exception类的异常都是在运行期间发生的）。
　　checked exception（检查异常），也称非运行时异常（运行时异常以外的异常就是非运行时异常），java编译器强制程序员必须进行捕获处理，比如常见的IOExeption和SQLException。对于非运行时异常如果不进行捕获或者抛出声明处理，编译都不会通过。

异常结构图：
![异常结构图](https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/Java%E5%BC%82%E5%B8%B8%E5%9B%BE%E7%89%87/%E5%BC%82%E5%B8%B8%E7%B1%BB%E7%BB%93%E6%9E%84%E5%B1%82%E6%AC%A1.jpg)

### 四、异常处理
System.out.println(e)和e.printStackTrace()
一般使用：e.printStackTrace()

### 五、java.util.logging.Logger
Java中实现日志记录经常使用Java自带的Logger,下面例子，全局日志记录器来生成简单的日志记录：
Logger.getGlobal().info("log"); 



