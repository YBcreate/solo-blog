title: nginx负载均衡
date: '2019-11-29 15:49:54'
updated: '2019-11-29 15:49:54'
tags: [nginx]
permalink: /articles/2019/11/29/1575013794418.html
---
### 例子

```
http{

.......
    upstream tomcatserver1 {  
	ip_hash;
   	server 192.168.72.49:8080 weight=1;  
    	server 192.168.72.49:8081 weight=1;  
    }
......
    server {
	.......
        location / {
            proxy_pass   http://tomcatserver1;  
	    proxy_connect_timeout 10;
            index  index.html index.htm;  
        }
	......
     }
}
```

负载均衡策略;
1、轮询（默认）
每个请求按时间顺序逐一分配到不同的后端服务器，如果后端服务器down掉，能自动剔除。
2、weight（权重）
weight代表权重，默认为 1, 权重越高被分配的客户端越多
指定轮询几率，weight和访问比率成正比，用于后端服务器性能不均的情况。
3、ip_hash
每个请求按访问ip的hash结果分配，这样每个访客固定访问一个应用服务器，可以解决session共享的问题。
4、fair（第三方）
按后端服务器的响应时间来分配请求，响应时间短的优先分配。
配置例子：
```
upstream server_pool{ 
	server 192.168.5.21:80; 
	server 192.168.5.22:80; 
	fair; 
}
```














