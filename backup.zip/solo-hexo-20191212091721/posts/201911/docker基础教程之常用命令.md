title: docker基础教程之常用命令
date: '2019-11-27 09:17:02'
updated: '2019-12-09 11:10:43'
tags: [docker, LINUX]
permalink: /articles/2019/11/27/1574817422898.html
---
### 一、docker基本组成
#### 1、镜像
Docker 镜像（Image）就是一个**只读**的模板。镜像可以用来创建 Docker 容器，一个镜像可以创建很多容器。
#### 2、容器
Docker 利用容器（Container）独立运行的一个或一组应用。容器是用镜像创建的运行实例。它可以被启动、开始、停止、删除。每个容器都是相互隔离的、保证安全的平台。
***可以把容器看做是一个简易版的 Linux 环境***（包括root用户权限、进程空间、用户空间和网络空间等）和运行在其中的应用程序。容器的定义和镜像是差不多的。也是一堆层的统一视角，唯一区别在于容器的最上面那一层是可读可写的。
#### 3、仓库（Repository）
仓库（Repository）是集中存放镜像文件的场所。仓库(Repository)和仓库注册服务器（Registry）是有区别的。仓库注册服务器上往往存放着多个仓库，每个仓库中又包含了多个镜像，每个镜像有不同的标签（tag）。
仓库分为公开仓库（Public）和私有仓库（Private）两种形式。最大的公开仓库是 Docker Hub(https://hub.docker.com/)，存放了数量庞大的镜像供用户下载。国内的公开仓库包括阿里云 、网易云等。

### 二、docker帮助命令
版本：`docker version`
具体信息：`docker info`
帮助：`docker --help`

### 三、docker镜像命令
#### 1、列出本地镜像：`docker images`
选项说明：
　　REPOSITORY：表示镜像的仓库源
　　TAG：镜像的标签
　　IMAGE ID：镜像ID
　　CREATED：镜像创建时间
　　SIZE：镜像大小
PTIONS说明：
　　-a :列出本地所有的镜像（含中间映像层，默认情况下，过滤掉中间映像层）；
　　--digests :显示镜像的摘要信息；
　　-f :显示满足条件的镜像；
　　--format :指定返回值的模板文件；
　　--no-trunc :显示完整的镜像信息；
　　-q :只显示镜像ID

#### 2、从Docker Hub查找镜像
`docker search 某个XXX镜像名字`
从Docker Hub查找镜像，网址：`https://hub.docker.com`
语法：`docker search [OPTIONS] TERM`
OPTIONS说明：
　　--automated :只列出 automated build类型的镜像；
　　--no-trunc :显示完整的镜像描述；
　　-s :列出收藏数不小于指定值的镜像。
#### 3、下载镜像
`docker pull 某个XXX镜像名字`
#### 4、删除镜像
`docker rmi 某个XXX镜像名字ID`
删除单个镜像：`docker rmi -f 镜像ID`
删除多个镜像：`docker rmi -f 镜像名1:TAG 镜像名2:TAG​`
删除全部：`docker rmi -f $(docker images -qa)`

### 三、容器命令
#### 1、列出当前正在运行的容器：`docker ps [OPTIONS]`
OPTIONS说明：
　　-a :显示所有的容器，包括未运行的。
　　-f :根据条件过滤显示的内容。
　　--format :指定返回值的模板文件。
　　-l :显示最近创建的容器。
　　-n :列出最近创建的n个容器。
　　--no-trunc :不截断输出。
　　-q :静默模式，只显示容器编号。
　　-s :显示总的文件大小。
例子：`docker ps -a`
#### 2、新建并启动容器
`docker run [OPTIONS] [COMMAND]​ [ARG...]`
 OPTIONS说明（有些是一个减号，有些是两个减号）：
　　--name="容器新名字": 为容器指定一个名称；
　　-d: 后台运行容器，并返回容器ID，也即启动守护式容器；
　　-i：以交互模式运行容器，通常与 -t 同时使用；
　　-t：为容器重新分配一个伪输入终端，通常与 -i 同时使用；
　　-P: 随机端口映射；
　　-p: 指定端口映射，有以下四种格式：
　　ip:hostPort:containerPort，ip::containerPort，hostPort:containerPort，containerPort
启动交互式容器例子（前提：已经下载centos容器）：docker run -it centos /bin/bash

### 四、退出容器
1、exit（容器停止退出）；2、ctrl+P+Q（容器不停止退出）
### 五、启动容器
docker start 容器ID或者容器名
### 六、重启容器
docker restart 容器ID或者容器名
### 七、停止容器
docker kill 容器ID或者容器名
### 八、删除已停止容器
docker rmi 容器ID或容器名

### 九、启动守护式容器
docker run -d 容器名(Docker容器后台运行,就必须有一个前台进程.)
### 十、查看容器日志
`docker logs -f -t --tail 容器ID`
*   -t 是加入时间戳
*   -f 跟随最新的日志打印
*   --tail 数字 显示最后多少条
### 十一、查看容器运行的进程
`docker top 容器ID`
### 十二、查看容器内部细节
`docker inspect 容器ID`
### 十三、进入正在运行的容器并以命令行交互
`docker exec -it 容器ID bashShell`
重新进入；`docker attach 容器ID`
上面两个命令的区别：
attach：直接进入容器启动命令的终端，不会启动新的进程
exec；是在容器中打开新的终端，并且可以启动新的进程

### 十四、从容器内拷贝文件到主机上
docker cp  容器ID:容器内路径 目的主机路径
例子：docker cp 975e29201b84:/usr/local/test.txt /tmp/c.txt

### 十五、安装管理页面插件（进入管理页面必须安装此插件）
`通过：docker exec -it 容器名称 sh ，进入docker容器中，执行：rabbitmq-plugins enable rabbitmq_management`



