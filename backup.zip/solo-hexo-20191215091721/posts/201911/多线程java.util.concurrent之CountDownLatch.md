title: 多线程：java.util.concurrent 之 CountDownLatch
date: '2019-11-18 10:53:10'
updated: '2019-12-12 11:38:32'
tags: [多线程]
permalink: /articles/2019/11/18/1574045590796.html
---
### CountDownLatch介绍
　　CountDownLatch是一个同步工具类，它允许一个或多个线程一直等待，直到其他线程执行完后再执行。
### CountDownLatch原理
　　CountDownLatch是通过一个计数器来实现的，计数器的初始化值为线程的数量。每当一个线程完成了自己的任务后，计数器的值就相应得减1。当计数器到达0时，表示所有的线程都已完成任务，然后在闭锁上等待的线程就可以恢复执行任务。
### CountDownLatch使用场景
　　**1、实现最大的并行性** 
　　注意是并行性，不是并发；做法是初始化一个共享的CountDownLatch(1)，将其计数器初始化为1，多个线程在开始执行任务前首先 `coundownlatch.await()`，当主线程调用 `countDown()` 时，计数器变为0，多个线程同时被唤醒
　　**2、开始执行前等待N个线程完成各自任务** 
　　例子：在并发中按顺序执行打印1、2、3
　　public class Foo {
    private CountDownLatch countDownLatchA;
    private CountDownLatch countDownLatchB;

    public Foo() {
        countDownLatchA = new CountDownLatch(1);
        countDownLatchB = new CountDownLatch(1);
    }

    // First will run first. Leave a mark after task done.
    public void first(Runnable printFirst) throws InterruptedException {
        // printFirst.run() outputs "first". Do not change or remove this line.
        printFirst.run();
        countDownLatchA.countDown();
    }

    // Keep waiting util First task set its mark.
    public void second(Runnable printSecond) throws InterruptedException {
        countDownLatchA.await();
        // printSecond.run() outputs "second". Do not change or remove this line.
        printSecond.run();
        countDownLatchB.countDown();
    }

    // Same as Second task.
    public void third(Runnable printThird) throws InterruptedException {
        countDownLatchB.await();
        // printThird.run() outputs "third". Do not change or remove this line.
        printThird.run();
    }
}
　　**3、产生的死锁**
当高并发请求时，countdownlatch的await方法有可能会引起死锁。如果使用的线程池数量较少，在高并发时会出现多个请求占用了全部的线程资源，但是每个请求又需要await其他线程，其他线程在等待线程池资源，导致多个请求同时进入线程阻塞，最后形成死锁。
解决方法，使用自定义线程池，扩大线程数量，并且建立线程池拒绝机制。
　　
