title: eureka使用记录
date: '2019-12-14 13:48:54'
updated: '2019-12-14 16:05:41'
tags: [springcloud]
permalink: /articles/2019/12/14/1576302534562.html
---
分布式系统中，服务注册中心是最重要的基础部分，eureka有心跳检测、健康检查、负载均衡等功能，虽然eureka官方已经宣布不再维护更新，不过其实 Eureka 已经很稳定了，当做注册中心完全没有问题。
### 1、eureka分为server端和client端
**server端即服务注册中心**，支持高可用配置，依托于强一致性提供良好的服务实例可用性，可以应对多种故障场景；
**client端处理服务的注册和发现**，客户端服务通过注册和参数配置的方式，嵌入在客户端应用程序的代码中。在应用程序启动时，Eureka客户端向服务注册中心注册自身提供的服务，并周期性的发送心跳来更新它的服务租约。同时，他也能从服务端查询当前注册的服务信息并把它们缓存到本地并周期行的刷新服务状态。

**server端主要配置：**
pom.xml
```
<dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-netflix-eureka-server</artifactId>
 </dependency>
```
application.yml
```
spring:
  application:
    name: eureka
eureka:
  client:
    service-url:
      defaultZone: http://localhost:8761/eureka/
    register-with-eureka: true
  server:
    enable-self-preservation: false
server:
  port: 8761
```
Application 添加注解:
```
@EnableEurekaServer
```

**client端主要配置**
pom.xml
```
<dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
</dependency>
```
application.yml
```
eureka:
  client:
    service-url:
      defaultZone: http://localhost:8761/eureka/
  instance:
    hostname: clientName
spring:
  application:
      name: client
server:
  port: 8080
```
Application 添加注解:
```
@EnableDiscoveryClient
```
### 2、eureka的高可用
eureka做为注册中心，上线都肯定要达到高可用，避免单点故障，下面展示2个server端，1个client端的主要配置：
server1：
pom.xml
```
<dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-netflix-eureka-server</artifactId>
</dependency>
```
application.yml
```
spring:
  application:
    name: eureka
eureka:
  client:
    service-url:
      defaultZone: http://localhost:8762/eureka/
    register-with-eureka: true
  server:
    enable-self-preservation: false
server:
  port: 8761
```
Application 添加注解:

```
@EnableEurekaServer
```

server2的配置差不多，只是在yml配置注册到server1：
pom.xml
```
<dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-netflix-eureka-server</artifactId>
</dependency>
```
application.yml
```
spring:
  application:
    name: eureka
eureka:
  client:
    service-url:
      defaultZone: http://localhost:8761/eureka/
    register-with-eureka: true
  server:
    enable-self-preservation: false
server:
  port: 8762
```
Application 添加注解:

```
@EnableEurekaServer
```

client端：

**client端主要配置**
pom.xml
```
<dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
</dependency>
```
application.yml
```
eureka:
  client:
    service-url:
      defaultZone: http://localhost:8761/eureka/,http://localhost:8762/eureka/
  instance:
    hostname: clientName
spring:
  application:
      name: client
server:
  port: 8080
```
Application 添加注解:
```
@EnableDiscoveryClient
```

效果图：
![eureka](https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/springcloud/eureka/eureka%E9%AB%98%E5%8F%AF%E7%94%A8%E7%A4%BA%E4%BE%8B.png)

源码：https://github.com/YBcreate/eurekaDemo
