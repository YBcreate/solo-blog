title: SQL记录
date: '2019-10-28 17:48:06'
updated: '2019-11-06 19:36:37'
tags: [SQL]
permalink: /articles/2019/10/28/1572256086405.html
---
**SqlServer获取第一条查询记录：**
　　select top 1 * from tb where .... order by ....

**SqlServer将字段进行分组（根据author进行分组，并根据create_time降序排序）**
　　ROW_NUMBER() over( partition by create_author order by create_time desc) as RowNumber
　　RowNumber作为条件时不能直接使用，要加一层查询：例子：
　　select * from(
　　select ROW_NUMBER() OVER(ORDER BY dbo.OrderOutProduct.ID) AS RowNumber,
　　dbo.Order.ID,Telephone,AddressCity,Province, from dbo.Order  
　　inner join dbo.Order2
　　on dbo.Order.ID=Order2ID
　　inner join dbo.Order3
　　on dbo.Order2.OrderID=dbo.Order3.Order3
　　where Service=1
　　)U where RowNumber=1

**SqlServer查询条件：charindex的使用**
charindex类似于js的indexOf关键字，因为sql用'%%'中间放变量并不方便（其实不知道怎么在里面放查询字段作为变量）
在left中可以使用charindex(soe.id,soe2.hierarchy_id)>0 作为条件等灵活用法
例子：
select sop.email from products_latest_version eplv
left join org_daoQiTiXingRenYuan ed on eplv.id = ed.parent_id
left join sys_org_element soe on soe.id = ed.sys_org_element_id
left join sys_org_element soe2 on charindex(soe.id,soe2.hierarchy_id)>0  
left join sys_org_person sop on soe2.id = sop.id
where soe.fd_org_type = '2' and DATEDIFF(dd,eplv.pSWDaoQiRiQi,GETDATE()) <= 30 
and soe2.org_type = '8'

**查询与某个时间所有交集**
select * from TABLENAME where  
    (starttime > a AND starttime < b) OR 
    (starttime < a AND endtime > b) OR
    (endtime > a AND endtime < b) OR
    (starttime = a AND endtime = b);
