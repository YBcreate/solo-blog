title: 未来需要填的坑（立flag）
date: '2019-11-29 16:42:55'
updated: '2019-11-29 16:50:02'
tags: [待分类]
permalink: /articles/2019/11/29/1575016975675.html
---
1、分布式各类知识
2、高可用集群（nginx、redis等等）
3、多线程
4、设计模式
5、算法
6、sql高级用法
7、JVM
8、各类软件系统（SVN、GIT、postman等等）
