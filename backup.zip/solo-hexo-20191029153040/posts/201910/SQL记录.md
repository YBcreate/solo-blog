title: SQL记录
date: '2019-10-28 17:48:06'
updated: '2019-10-28 17:48:18'
tags: [SQL]
permalink: /articles/2019/10/28/1572256086405.html
---
SqlServer获取第一条查询记录：
select top 1 * from tb where .... order by ....
