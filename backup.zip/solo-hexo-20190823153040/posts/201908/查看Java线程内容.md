title: 查看Java线程内容
date: '2019-08-22 14:52:45'
updated: '2019-08-23 08:49:40'
tags: [JVM]
permalink: /articles/2019/08/22/1566456765326.html
---
CPU消耗过高、死锁、死循环、线程阻塞等问题定位可以通过以下方法解决：
1、ps -ef | grep java找到你的java程序的进程id, 定位 pid
2、top -Hp $pid 查看线程的堆栈
3、printf '%x\n' pid  (pid是上一个命令查出的线程id，此命令是将id转十六进制)
4、把上诉线程ID转换成16进制小写  比如  : 0x12ef
5、kill -3 $pid  触发tomcat的thread dump
6、找到tomcat的catalin.out 日志,并通过上述16进制数字找到对应的线程日志

内存溢出报错定位：
1、如果设置了-XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/home/tomcat/logs/，就可以直接到/home/tomcat/logs/这个路径下找.hprof文件，使用专门的软件进行分析，例如：Memory Analyzer，或者直接导入eclipse，导入的时候会提示下载插件，如果不指定选项“XX:HeapDumpPath”则在当前目录下生成dump文件
