title: shiro篇之realm
date: '2019-08-09 10:01:26'
updated: '2019-08-29 09:34:16'
tags: [shiro]
permalink: /articles/2019/08/09/1565316086142.html
---
**realm的配置**
### **1、IniRealm**
通过读取.ini配置文件来获取用户，角色，权限信息
ini配置文件完整的结构如下：
```
[main]
# Objects and their properties are defined here,
# Such as the securityManager, Realms and anything
# else needed to build the SecurityManager

[users]
# The 'users' section is for simple deployments
# when you only need a small number of statically-defined
# set of User accounts.

[roles]
# The 'roles' section is for simple deployments
# when you only need a small number of statically-defined
# roles.

[urls]
# The 'urls' section is used for url-based security
# in web applications.  We'll discuss this section in the
# Web documentation
```
例子：
```
[users] 
zhangsan =123456,admin 

[roles] 
admin = user:delete,user:select;
```
shiro realm认证代码如下：

```
import org.apache.shiro.SecurityUtils; 
import org.apache.shiro.authc.AuthenticationException; 
import org.apache.shiro.authc.UsernamePasswordToken; 
import org.apache.shiro.mgt.DefaultSecurityManager; 
import org.apache.shiro.realm.Realm; 
import org.apache.shiro.realm.text.IniRealm; 
import org.apache.shiro.subject.Subject; 
import org.junit.Test; 

public class IniRealmTest { 
    @Test 
    public void IniRealm() { 
        DefaultSecurityManager defaultSecurityManager = new DefaultSecurityManager(); 
        Realm iniRealm = new IniRealm("classpath:shiro.ini"); 
        defaultSecurityManager.setRealm(iniRealm); 
        SecurityUtils.setSecurityManager(defaultSecurityManager); 
        Subject subject = SecurityUtils.getSubject(); 
        UsernamePasswordToken token = new UsernamePasswordToken("zhangsan", "123456"); 
        try { 
            subject.login(token); 
        } catch (AuthenticationException e) { 
            e.printStackTrace(); 
            System.out.println("登陆失败"); 
        } 
        System.out.println("认证结果："+subject.isAuthenticated()); 
        System.out.println("是否有admin 权限: " + subject.hasRole("admin")); 
        System.out.println("是否有user:delete权限：" + subject.isPermitted("user:delete")); 
    } 
}
```

运行结果：
**认证结果：true**
**是否有admin 权限: true**
**是否有user:delete权限：true**

项目结构：
![avatar](https://xieyongbinpicture.oss-cn-shenzhen.aliyuncs.com/%E9%A1%B9%E7%9B%AE%E7%BB%93%E6%9E%84.png)


### **2、JdbcRealm**
JdbcRealm使用到数据库连接池，及数据库表的创建，可以使用shiro默认的表查询，也可以自定义表查询；具体可以查看org.apache.shiro.realm.jdbc.JdbcRealm下的源码；

**（1）需要先导入mysql和数据库连接池jar包**
```
<dependency> 
    <groupId>mysql</groupId> 
    <artifactId>mysql-connector-java</artifactId> 
    <version>5.1.32</version> 
</dependency> 
<dependency> 
    <groupId>com.alibaba</groupId> 
    <artifactId>druid</artifactId> 
    <version>1.1.10</version> 
</dependency>
```
**（2）创建数据库表和初始化数据**
SET FOREIGN_KEY_CHECKS=0; 
-- ---------------------------- 
-- Table structure for roles_permissions 
-- ---------------------------- 
DROP TABLE IF EXISTS `roles_permissions`; 
CREATE TABLE `roles_permissions` ( 
  `id` bigint(20) NOT NULL AUTO_INCREMENT, 
  `role_name` varchar(100) DEFAULT NULL, 
  `permission` varchar(100) DEFAULT NULL, 
  PRIMARY KEY (`id`), 
  UNIQUE KEY `idx_roles_permissions` (`role_name`,`permission`) 
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8; 
-- ---------------------------- 
-- Records of roles_permissions 
-- ---------------------------- 
INSERT INTO `roles_permissions` VALUES ('1', 'admin', 'user:delete'); 
INSERT INTO `roles_permissions` VALUES ('2', 'user', 'user:select'); 
-- ---------------------------- 
-- Table structure for users 
-- ---------------------------- 
DROP TABLE IF EXISTS `users`; 
CREATE TABLE `users` ( 
  `id` bigint(20) NOT NULL AUTO_INCREMENT, 
  `username` varchar(100) DEFAULT NULL, 
  `password` varchar(100) DEFAULT NULL, 
  `password_salt` varchar(100) DEFAULT NULL, 
  PRIMARY KEY (`id`), 
  UNIQUE KEY `idx_users_username` (`username`) 
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8; 
-- ---------------------------- 
-- Records of users 
-- ---------------------------- 
INSERT INTO `users` VALUES ('1', 'zhangsan', '123456', null); 
-- ---------------------------- 
-- Table structure for user_roles 
-- ---------------------------- 
DROP TABLE IF EXISTS `user_roles`; 
CREATE TABLE `user_roles` ( 
  `id` bigint(20) NOT NULL AUTO_INCREMENT, 
  `username` varchar(100) DEFAULT NULL, 
  `role_name` varchar(100) DEFAULT NULL, 
  PRIMARY KEY (`id`), 
  UNIQUE KEY `idx_user_roles` (`username`,`role_name`) 
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8; 
-- ---------------------------- 
-- Records of user_roles 
-- ---------------------------- 
INSERT INTO `user_roles` VALUES ('1', 'zhangsan', 'admin'); 
INSERT INTO `user_roles` VALUES ('2', 'zhangsan', 'user');
**（3）测试代码**
```
import com.alibaba.druid.pool.DruidDataSource; 
import org.apache.shiro.SecurityUtils; 
import org.apache.shiro.authc.AuthenticationException; 
import org.apache.shiro.authc.UsernamePasswordToken; 
import org.apache.shiro.mgt.DefaultSecurityManager; 
import org.apache.shiro.realm.jdbc.JdbcRealm; 
import org.apache.shiro.subject.Subject; 
import org.junit.Before; 
import org.junit.Test; 
import java.util.Arrays; 


public class JdbcRealmTest { 
    private DruidDataSource dataSource = new DruidDataSource(); 

    /** 
     * 初始化 DataSource 
     */ 
    @Before 
    public void before() { 
        dataSource.setDriverClassName("com.mysql.jdbc.Driver"); 
        dataSource.setUrl("jdbc:mysql://127.0.0.1:3306/shiro"); 
        dataSource.setUsername("root"); 
        dataSource.setPassword("root"); 
    } 

    @Test 
    public void testJdbcRealm() { 
        DefaultSecurityManager defaultSecurityManager = new DefaultSecurityManager(); 

        // 构建 JdbcRelam 
        JdbcRealm jdbcRealm = new JdbcRealm(); 
        // 为 JdbcRelam 设置数据源 
        jdbcRealm.setDataSource(dataSource); 
        // 设置启用权限查询, 默认为 false 
        jdbcRealm.setPermissionsLookupEnabled(true); 

        defaultSecurityManager.setRealm(jdbcRealm); 
        SecurityUtils.setSecurityManager(defaultSecurityManager); 
        Subject subject = SecurityUtils.getSubject(); 

        UsernamePasswordToken token = new UsernamePasswordToken("zhangsan", "123456"); 

        try { 
            subject.login(token); 
        } catch (AuthenticationException e) { 
            e.printStackTrace(); 
            System.out.println("登陆失败"); 
        } 

       System.out.println("是否有admin权限："+subject.hasRole("admin"));   
       System.out.println("是否有user权限: "+subject.hasRole("user")); 
    } 
}
```

### **3、自定义realm**
在实际项目中，一般通过继承AuthorizingRealm实现自定义realm
（1）自定义realm需要继承 AuthorizingRealm 
```
import com.xieyongbin.entity.User;
import com.xieyongbin.service.IUserService;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.Map;
import java.util.Set;

/**
 * Created by Administrator on 2017/10/11.
 */
public class MyRealm extends AuthorizingRealm {

    @Autowired
    private IUserService userService;

    /**
     * 授权
     *
     * @param principals
     * @return
     */
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
        String userName = (String) principals.getPrimaryPrincipal();
        SimpleAuthorizationInfo auth = new SimpleAuthorizationInfo();
        Map<String, Object> map = null;
        try {
            map = this.userService.getRolesAndPermissionsByUserName(userName);
            auth.setRoles((Set<String>) map.get("allRoles"));
            auth.setStringPermissions((Set<String>) map.get("allPermissions"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return auth;
    }

    /**
     * 认证
     *
     * @param token
     * @return
     * @throws AuthenticationException
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        String userName = (String) token.getPrincipal();
        User vo = this.userService.getUserByUserName(userName);
        if (vo == null) {
            throw new UnknownAccountException("该用户名称不存在！");
        } else if (vo.getLock() == null || vo.getLock().equals(1)) {
            throw new UnknownAccountException("该用户已经被锁定了！");
        } else {
            String password = new String((char[]) token.getCredentials());
            if (vo.getPassword().equals(password)) {
                AuthenticationInfo authcInfo = new SimpleAuthenticationInfo(vo.getUserName(), vo.getPassword(), vo.getUserName());
                SecurityUtils.getSubject().getSession().setAttribute("currentUser", vo);
                return authcInfo;
            } else {
                throw new IncorrectCredentialsException("密码错误！");
            }
        }
    }

}
```
* `doGetAuthenticationInfo` : 获取用户认证信息，在这里我们不需要校验密码是否正确，因为有专门的密码校验器来做这件事，我们只需要返回认证信息即可。 (认证信息在这个示例中为 `SimpleAuthenticationInfo`， 即账号密码)  
    当然你也可以在返回认证信息前根据用户的状态，如冻结，锁定，或登陆次数来抛出相应的异常，以直接返回登陆失败，而不再进行密码校验。
* `doGetAuthorizationInfo` : 获取用户授权信息，授权信息包括所拥有的角色和权限信息，这里的逻辑很简单，只需要根据用户信息查询出角色和权限，配置到 `AuthorizationInfo` 中返回即可




