title: SQL记录
date: '2019-10-28 17:48:06'
updated: '2019-10-30 15:04:37'
tags: [SQL]
permalink: /articles/2019/10/28/1572256086405.html
---
SqlServer获取第一条查询记录：
　　select top 1 * from tb where .... order by ....

SqlServer将字段进行分组（根据author进行分组，并根据create_time降序排序）
　　ROW_NUMBER() over( partition by create_author order by create_time desc) as RowNumber
　　RowNumber作为条件时不能直接使用，要加一层查询：例子：
　　select * from(
　　select ROW_NUMBER() OVER(ORDER BY dbo.OrderOutProduct.ID) AS RowNumber,
　　dbo.Order.ID,Telephone,AddressCity,Province, from dbo.Order  
　　inner join dbo.Order2
　　on dbo.Order.ID=Order2ID
　　inner join dbo.Order3
　　on dbo.Order2.OrderID=dbo.Order3.Order3
　　where Service=1
　　)U where RowNumber=1
