title: linux挂载
date: '2019-10-08 11:02:08'
updated: '2019-10-08 11:02:08'
tags: [LINUX]
permalink: /articles/2019/10/08/1570503728305.html
---
**挂载概念简述**：

根文件系统之外的其他文件要想能够被访问，都必须通过“关联”至根文件系统上的某个目录来实现，此关联操作即为“**挂载**”，此目录即为“**挂载点**”,解除此关联关系的过程称之为“**卸载**”

1.挂载：根文件系统外通过关联至根文件系统上的某个目录来实现访问

2.挂载点：mount_point，用于作为另一个文件系统的访问入口；

**(1) 事先存在；**

**(2) 应该使用未被或不会被其它进程使用到的目录；**

**(3) 挂载点下原有的文件将会被隐藏；**

**挂载步骤例子**
1、创建挂载目录
例如：/usr/local/bin/code
2、使用利用 mount 命令进行挂载
例如：mount -t cifs -o username=Bob,password=123456 //192.168.0.102/Share /usr/local/bin/code

**挂载完成后我们就可以在 `/usr/local/bin/code` 目录里面看到 Windows 共享文件夹里面的文件**

3、**查挂载在状态**
命令：df -h ，或者使用：mount命令查看

4、**卸载**
例子：umount /usr/local/bin/code

umount 时提示错误 target is busy. (In some cases useful info about processes that use the device is found by lsof(8) or fuser(1)) , 你可以先切换到别的目录再试一次 , 原因也可能是其他进程可能在使用目录 , 可以先关闭使用该目录的进程 , 然后再 umount , 命令如下 (使用 fuser 需安装 psmisc # yum install psmisc)： 

\# fuser -m /usr/local/bin/code
/usr/local/bin/code:  2806c

\# ps aux | grep 2806
root      2806  0.0  0.5 116040  2836 pts/0    Ss   11:31   0:00 -bash
root      2925  0.0  0.1 112648   960 pts/0    S+   14:36   0:00 grep --color=auto 2806

\# kill -9 2806

\# umount /usr/local/bin/code
