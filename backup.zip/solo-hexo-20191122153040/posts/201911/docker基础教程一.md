title: docker基础教程（一）
date: '2019-11-19 09:28:17'
updated: '2019-11-19 09:28:17'
tags: [docker]
permalink: /articles/2019/11/19/1574126897092.html
---
Docker提供了轻量级的虚拟化，几乎没有任何额外开销，非常轻巧快速，它为基于虚拟机管理程序的虚拟机提供了可行、经济、高效的替代方案。


### Docker 引擎服务的启动和关闭
**启动 Docker 引擎服务**
　　service docker start
**关闭 Docker 引擎服务**
　　service docker stop

### Docker 引擎的卸载
**卸载 Docker 引擎**
　　`sudo yum remove docker  docker-common docker-selinux docker-engine`
**删除镜像、容器、卷及自定义的配置文件**
　　rm -rf /var/lib/docker

### Docker 在Centos上的安装
* Centos 版本需要为 7.X 及以上
* Centos 需为 64位操作系统

**Yum 安装 Docker**

**更新yum包**
`yum update`
安装需要的软件包， yum-util 提供yum-config-manager功能，另外两个是devicemapper驱动依赖的
`$ sudo yum install -y yum-utils device-mapper-persistent-data lvm2`
**设置yum源**
`$ sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo`

**可以查看所有仓库中所有docker版本，并选择特定版本安装**
`$ yum list docker-ce --showduplicates | sort -r`

**安装docker**
```
$ sudo yum install docker-ce  #由于repo中默认只开启stable仓库，故这里安装的是最新稳定版17.12.0
$ sudo yum install <FQPN>  # 例如：sudo yum install docker-ce-17.12.0.ce
```

**启动并加入开机启动**
```
$ sudo systemctl start docker
$ sudo systemctl enable docker
```

**验证安装是否成功(有client和service两部分表示docker安装启动都成功了)**
`docker version`

### 报错
因为之前已经安装过旧版本的docker，在安装的时候报错如下：
```
Transaction check error:
  file /usr/bin/docker from install of docker-ce-17.12.0.ce-1.el7.centos.x86_64 conflicts with file from package docker-common-2:1.12.6-68.gitec8512b.el7.centos.x86_64
  file /usr/bin/docker-containerd from install of docker-ce-17.12.0.ce-1.el7.centos.x86_64 conflicts with file from package docker-common-2:1.12.6-68.gitec8512b.el7.centos.x86_64
  file /usr/bin/docker-containerd-shim from install of docker-ce-17.12.0.ce-1.el7.centos.x86_64 conflicts with file from package docker-common-2:1.12.6-68.gitec8512b.el7.centos.x86_64
  file /usr/bin/dockerd from install of docker-ce-17.12.0.ce-1.el7.centos.x86_64 conflicts with file from package docker-common-2:1.12.6-68.gitec8512b.el7.centos.x86_64
```
**卸载旧版本的包**
`$ sudo yum erase docker-common-2:1.12.6-68.gitec8512b.el7.centos.x86_64`
