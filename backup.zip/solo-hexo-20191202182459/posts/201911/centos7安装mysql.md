title: centos7安装mysql
date: '2019-11-19 09:35:19'
updated: '2019-11-19 09:35:19'
tags: [SQL, mysql]
permalink: /articles/2019/11/19/1574127319061.html
---
#### 1、centos7默认安装的是mariadb，所以要安装mysql首先要卸载mariadb，否则会冲突。
列出mariadb：rpm -qa | grep mariadb
卸载mariadb:rpm -e mariadb-libs-5.5.37-1.el7_0.x86_64
#### 2、MySQL依赖libaio，阿里云ecs云服务要安装libaio
查看libaio：rpm -qa|grep libaio
没有则安装：yum -y install libaio

#### 3、卸载旧的mysql
查看：rpm -qa | grep mysql
可能有多个，逐个删除掉旧的组件：rpm -e --nodeps mysql-5.7.22-1.el7.x86_64


#### 4、下载对应版本：
可以到mysql官网查看，以下是Linux 7 64位版本
wget https://dev.mysql.com/get/Downloads/MySQL-5.7/mysql-5.7.22-1.el7.x86_64.rpm-bundle.tar


#### 5、按照依赖关系依次安装rpm包 依赖关系依次为common→libs→client→server
rpm -ivh mysql-community-common-5.7.22-1.el7.x86_64.rpm
rpm -ivh mysql-community-libs-5.7.22-1.el7.x86_64.rpm
rpm -ivh mysql-community-client-5.7.22-1.el7.x86_64.rpm
rpm -ivh mysql-community-server-5.7.22-1.el7.x86_64.rpm

注：ivh中， i-install安装；v-verbose进度条；h-hash哈希校验

#### 6、修改/etc/my.cnf来禁用密码
cd /etc
vim my.cnf

#### 7、在最下面添加：skip-grant-tables，之后保存退出

#### 8、重启mysql:systemctl restart mysqld.service，并直接进入mysql
[root@iZ25fftuiaeZ etc]# systemctl restart mysqld.service
[root@iZ25fftuiaeZ etc]# mysql -uroot

#### 9、更新mysql密码
mysql> update user set authentication_string=password("your_new_password") where user="root";

#### 10、使用quit退出mysql（登录：mysql -uroot -proot   <uroot是用户名，proot是密码>）
mysql> quit

#### 11、再次编辑/etc/my.cnf，把skip-grant-tables注释掉，不注释掉那就永远不需要密码就可以登录了

#### 12、重启mysql：systemctl restart mysqld.service

#### 13、之后正常登陆使用就行：mysql -uroot -pyour_new_password

#### 14、安装完之后要重新设置密码，不然会一直提示：You must reset your password .....，依次执行以下步骤：
SET PASSWORD = PASSWORD('新密码');
alter user 'root'@'localhost' password expire never;
flush privileges;

#### 15、初始密码策略：
查看：SHOW VARIABLES LIKE 'validate_password%'; 
设置：set global validate_password_policy=LOW;

#### 16、退出重新登录
