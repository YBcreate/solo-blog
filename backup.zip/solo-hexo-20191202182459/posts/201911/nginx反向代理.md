title: nginx反向代理
date: '2019-11-29 15:30:00'
updated: '2019-11-29 15:30:00'
tags: [nginx]
permalink: /articles/2019/11/29/1575012600485.html
---
### 例子一：
访问www.xxx.com就会自动跳转到http://127.0.0.1:8080路径
```
server {
      listen       80;
      server_name  www.xxx.com;
     
      location / {
          proxy_pass        http://127.0.0.1:8080;  
	  index  index.jsp index.html index.htm;
      }
```
### 例子二
访问http://127.0.0.1:9001/edu，跳转http://127.0.0.1:8081
访问http://127.0.0.1:9001/vod，跳转http://127.0.0.1:8082
```
server {
      listen       9001;
      server_name  localhost;
     
      location ~  /edu/ {
          proxy_pass        http://127.0.0.1:8081; 
      }

      location ~  /vod/ {
          proxy_pass        http://127.0.0.1:8082; 
      }
```
location指令匹配URL规则：
1、= ：用于不含正则表达式的 uri 前，要求请求字符串与 uri 严格匹配，如果匹配成功，就停止继续向下搜索并立即处理该请求。
2、~：用于表示 uri 包含正则表达式，并且区分大小写。
3、~*：用于表示 uri 包含正则表达式，并且不区分大小写。 
4、^~：用于不含正则表达式的 uri 前，要求 Nginx 服务器找到标识 uri 和请求字符串匹配度最高的 location 后，立即使用此 location 处理请求，而不再使用 location 块中的正则 uri 和请求字符串做匹配。 
注意：如果 uri 包含正则表达式，则必须要有 ~ 或者 ~* 标识。




