title: JVM调优：JDK1.7
date: '2019-08-15 13:59:49'
updated: '2019-08-15 13:59:49'
tags: [JVM]
permalink: /articles/2019/08/15/1565848789021.html
---
本文的调优针对JDK1.7

JVM涉及到的几个参数
1、-Xms
2、-Xmx
3、-XX:PermSize
4、-XX:MaxPermSize
5、-Xmn
