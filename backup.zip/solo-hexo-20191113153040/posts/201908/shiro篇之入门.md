title: shiro篇之入门
date: '2019-08-07 17:20:29'
updated: '2019-08-08 08:28:19'
tags: [shiro]
permalink: /articles/2019/08/07/1565169629219.html
---
### **摘要**
shiro是一个强大的Java 安全框架，shiro不依赖任何容器，可以直接在JavaEE中使用。
### **Shiro 功能介绍**
**shiro有四大核心：登录认证，权限验证，会话管理，数据加密；**
**shiro支持WEB开发，支持缓存，支持线程并发验证，支持测试，支持用户切换，支持"记住我"功能**
### **shiro架构介绍**
**Shiro 有三个主要的组件： Subject，SecurityManager，Realms**
1、Subject：指当前操作用户
2、SecurityManager：Shiro框架的核心，通过它来提供安全管理的各种服务
3、Realm：Realm充当了Shiro与应用安全数据间的“桥梁”或者“连接器”。当对用户执行认证（登录）和授权（访问控制）验证时，Shiro会从应用配置的Realm中查找用户及其权限信息。Realm实质上是一个安全相关的DAO，它封装了数据源的连接细节，并在需要时将相关数据提供给Shiro。当配置Shiro时，必须至少指定一个Realm，用于认证和（或）授权，也可以配置多个Realm。

**除Subject、SecurityManager 、Realm三个核心组件外，Shiro主要组件还包括：Authenticator、Authorization、SessionManager、CacheManager、Remember Me等；**
1、Authenticator：身份认证 / 登录，验证用户是不是拥有相应的身份；
2、Authorization：授权，即权限验证，验证某个已认证的用户是否拥有某个权限；即判断用户是否能做事情，常见的如：验证某个用户是否拥有某个角色。或者细粒度的验证某个用户对某个资源是否具有某个权限；
3、SessionManager：会话管理，即用户登录后就是一次会话，在没有退出之前，它的所有信息都在会话中；会话可以是普通 JavaSE 环境的，也可以是如 Web 环境的；
4、CacheManager：加密，保护数据的安全性，如密码加密存储到数据库，而不是明文存储；
5、Caching：缓存，比如用户登录后，其用户信息、拥有的角色 / 权限不必每次去查，这样可以提高效率；
6、Remember Me：记住我，这个是非常常见的功能，即一次登录后，下次再来的话不用登录了。
**注：Shiro 不会去维护用户、维护权限；这些需要我们自己去设计 / 提供；然后通过相应的接口注入给 Shiro 即可**
### **Shiro的认证过程**
1、收集实体/凭据信息
UsernamePasswordToken支持最常见的用户名/密码的认证机制。同时，由于它实现了RememberMeAuthenticationToken接口，我们可以通过令牌设置“记住我”的功能，但是，“已记住”和“已认证”是有区别的；已记住的用户仅仅是非匿名用户，你可以通过subject.getPrincipals()获取用户信息。但是它并非是完全认证通过的用户，当你访问需要认证用户的功能时，你仍然需要重新提交认证信息。
例子：
UsernamePasswordToken token = new UsernamePasswordToken(username, password);   
token.setRememberMe(true);

2、提交实体/凭据信息
收集了实体/凭据信息之后，我们可以通过SecurityUtils工具类，获取当前的用户，然后通过调用login方法提交认证
例子：
Subject currentUser = SecurityUtils.getSubject();  
currentUser.login(token);

3、认证处理
上一步try{}catch(){}处理，如果没有异常便认为用户认证通过，之后在应用程序任意地方调用SecurityUtils.getSubject() 都可以获取到当前认证通过的用户实例，使用subject.isAuthenticated()判断用户是否已验证都将返回true.
例子：
Map result = new HashMap<>();
try {
    currentUser.login(token);  
} catch ( Exception e) {
    result.put("code", "1024"); 
    result.put("msg","登录认证失败");
}
return result;

Shiro有着丰富的层次鲜明的异常类来描述认证失败的原因：
例子：
UnknownAccountException：没有找到账号异常
LockedAccountException：账号锁定
UnsupportedTokenException：身份令牌异常，不支持的身份令牌
DisabledAccountException：用户禁用
ExcessiveAttemptsException：登录重试次数，超限
ConcurrentAccessException：一个用户多次登录异常
.
.
.


### **退出**
登出操作可以通过调用subject.logout()来删除你的登录信息 
SecurityUtils.getSubject().logout();




**下篇文章将记录shiro主要组件，也是主要开发设置的地方**