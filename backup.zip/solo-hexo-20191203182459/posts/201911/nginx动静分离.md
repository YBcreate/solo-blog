title: nginx动静分离
date: '2019-11-29 16:39:31'
updated: '2019-11-29 16:52:15'
tags: [nginx]
permalink: /articles/2019/11/29/1575016771125.html
---
### 动静分离从目前实现角度来讲大致分为两种
一种是纯粹把静态文件独立成单独的域名，放在独立的服务器上，也是目前主流推崇的方案；
另外一种方法就是动态跟静态文件混合在一起发布，通过 nginx 来分开。
### 例子
```
server {
      listen   80;
      server_name  localhost;
      location /www/ {
	root   /data/;
	index  index.jsp index.html index.htm;
      }
      location /image/ {
	root   /data/;
	autoindex on;
      }
}
```	
autoindex：Nginx默认是不允许列出整个目录的，autoindex可以实现浏览目录功能
#### root和alias的区别
例如：
```
location /image/ {
	root   /data/;
	autoindex on;
      }
```
因为root属性指定的值是要加入到最终路径的，所以访问的位置变成了/data/image
```
location /image/ {
	alias  /data/;
	autoindex on;
      }
```
使用alias属性，其会抛弃URI，直接访问alias指定的位置, 所以最终路径变成/data/







